import random
import numpy as np

# function to get the l2 norm of a vector or matrix
l2 = lambda x: np.sqrt(np.sum(np.square(x)))


class Shooting(object):
    """
    @ivar x_transpose: [[float]] - transpose of the design matrix X
    @ivar y: [float] - response vector y
    @ivar lambduh: float - regularization parameter
    @ivar wplus: [float] - positive part of w
    @ivar wminus: [float] - negative part of w
    @ivar xw: [float] - product of Xw
    """

    def __init__(self, x_transpose, y, lambduh):
        self.x_transpose = x_transpose
        p, n = self.x_transpose.shape
        self.y = y
        self.lambduh = lambduh
        self.wplus = np.zeros(p)
        self.wminus = np.zeros(p)
        self.xw = np.zeros(n)


    def scd(self, maxiter):
        """
        Run Sequential SCD until convergence or exceeding maxiter
        @param maxiter: int - maximum number of iterations to run
        """
        p, n = self.x_transpose.shape

        iteration = 0
        while iteration < maxiter:
            self.shoot(p)
            # TODO: Your code goes here
            print >> sys.stderr, "Aborted: scd function not implemented."
            sys.exit(0)
        return w


    def shoot(self, K):
        """
        Perform coordinate descent at K random chosen coordinates
        @param K: int - number of coordinates
        """
        p, n = self.x_transpose.shape
        for i in range(K):
            j = random.randint(0, 2*p - 1)
            # TODO: Your code goes here

            print >> sys.stderr, "Aborted: shoot function not implemented."
            sys.exit(0)
