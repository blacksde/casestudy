"""
FMRI word prediction task
"""
import math
import time

import numpy as np
from scipy.io import mmread

from Shooting import Shooting

# Dimension of the input fmri feature
Xp = 21764
# Dimension of the output semantic feature
Yp = 218
# Number of training examples
ntrain = 300
# Number of test examples
ntest = 60

def shoot_single_feature(varidx, lambdas):
    """
    Run shotgun on a single feature varidx, using given lambdas
    @param varidx: int
    @param lambdas: [float]
    """
    # Read the word feature matrix
    # wordfeature[i] corresponds to the ith semantic feature.
    wordfeature_transpose = mmread("data/fmri/word_feature_std.mtx").T

    # Read the training data
    Xtrain_transpose = mmread("data/fmri/subject1_fmri_std.train.mtx").T
    widtrain = np.loadtxt("data/fmri/subject1_wordid.train.mtx")
    Ytrain_transpose = np.array([wordfeature_transpose[varidx][int(widtrain[j] - 1)] for j in range(ntrain)])

    # Read the test data
    Xtest_transpose = mmread("data/fmri/subject1_fmri_std.test.mtx").T
    # widtest is a 60 * 2 matrix.
    # The first column contains the true word id that generates the fmri signal.
    # The second column contains random selected word ids.
    widtest_transpose = mmread("data/fmri/subject1_wordid.test.mtx").T
    Ytest_transpose = np.array([wordfeature_transpose[varidx][int(widtest_transpose[0][j]) - 1] for j in range(ntest)])

    # Compute the laso fit for each lambda
    start = time.clock()
    print "Training for semantic feature: %d" % varidx
    results = []
    for lambduh in lambdas:
        print "Lambda: %.2f" % lambduh

        shooter = Shooting(Xtrain_transpose, Ytrain_transpose, lambduh)
        w_hat = shooter.scd(10 * Xp)
        #w_hat = Shooting.scd(Xtrain_transpose, Ytrain_transpose, lambduh, 10 * Xp)
        #w_hat = Shooting.scd(Xtrain_transpose, Ytrain_transpose, lambduh, 10 * Xp)
        print "NNZ: %.1f" % np.count_nonzero(w_hat)

        trainresid = Xtrain_transpose.T.dot(w_hat) - Ytrain_transpose
        trainerror = trainresid.dot(trainresid) / ntrain
        print "Training error: %f" % trainerror

        testresid = Xtest_transpose.T.dot(w_hat) - Ytest_transpose
        testerror = testresid.dot(testresid) / ntest
        print "Testing error: %f" % testerror

    print "Total time elapsed: %f seconds" % (time.clock() - start)


if __name__ == '__main__':
    # lambdas = [0.00, 0.01, ..., 0.15]
    lambdas = [i * 0.01 for i in range(16)]
    shoot_single_feature(0, lambdas)
